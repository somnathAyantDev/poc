import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import {HttpResponse} from '@angular/common/http';
import { HttpClient, HttpRequest, HttpHeaders, HttpEvent } from '@angular/common/http';
import { FileDto } from './fileDto';
import {UploadFileResponse} from './UploadFileResponse';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FileService {

  awsUrl:string;
  constructor(private nativeHttp: HttpClient) { }


  getFile(fileDto:FileDto): Observable<UploadFileResponse> {
 
    //this.awsUrl="http://ec2-3-82-199-8.compute-1.amazonaws.com:8080/springbootdeploy/students/saveStudent"
    this.awsUrl="http://localhost:8080/downloadFile/";
     
     return this.nativeHttp.get<UploadFileResponse>(this.awsUrl+fileDto.fileName);
  }

  uploadFile(uploadedFile:File): Observable<UploadFileResponse> {
 
    //this.awsUrl="http://ec2-3-82-199-8.compute-1.amazonaws.com:8080/springbootdeploy/students/saveStudent"
    this.awsUrl="http://localhost:8080/uploadFile";
    const formdata: FormData = new FormData();  
    formdata.append('file', uploadedFile);  
     return this.nativeHttp.post<UploadFileResponse>(this.awsUrl,formdata);
  }

}
