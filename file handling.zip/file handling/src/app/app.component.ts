import { FileDto } from './fileDto';
import { Component } from '@angular/core';
import { FormControl, Validators, FormBuilder, FormGroup } from '@angular/forms';
import {FileService} from './file.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'file-handling';
  studentForm: FormGroup;
  constructor(private fb: FormBuilder ,private fileService:FileService) { 

  }

  ngOnInit() {
    this.studentForm = this.fb.group({      // initializes all formcontrolnames and give the control to empForm hence it carries all values as a single object.
      'fileName' : new FormControl(''),
        });
  }

  getFile(fileDto:FileDto){   //emp is the model class object
    
    

    this.fileService.getFile(fileDto).subscribe((res) => {
      
       
        window.location.href=res.fileDownloadUri;
    },
      err => {
        alert("No such File found");
      },
      () => { console.log('Method Executed') }
    );
          
        }


}
