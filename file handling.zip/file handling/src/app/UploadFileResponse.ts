export class UploadFileResponse{

    fileName:string;
    fileDownloadUri:string;
    fileType:string;
    size:number;
}